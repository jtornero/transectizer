<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="es" sourcelanguage="en">
<context>
    <name>manualNamesDialog</name>
    <message>
        <location filename="ui_manualStationNaming.ui" line="17"/>
        <source>Manual Station naming</source>
        <translation>Detalles de estación Automáticos</translation>
    </message>
    <message>
        <location filename="ui_manualStationNaming.ui" line="32"/>
        <source>Accept</source>
        <translation>Aceptar</translation>
    </message>
    <message>
        <location filename="ui_manualStationNaming.ui" line="48"/>
        <source>Transect Name</source>
        <translation>Nombre del transecto</translation>
    </message>
    <message>
        <location filename="ui_manualStationNaming.ui" line="112"/>
        <source>Fix</source>
        <translation>Fijar</translation>
    </message>
    <message>
        <location filename="ui_manualStationNaming.ui" line="68"/>
        <source>Station prefix</source>
        <translation>Prefijo de Estación</translation>
    </message>
    <message>
        <location filename="ui_manualStationNaming.ui" line="88"/>
        <source>Station Number</source>
        <translation>Número de Estación</translation>
    </message>
    <message>
        <location filename="ui_manualStationNaming.ui" line="95"/>
        <source>Observations</source>
        <translation>Observaciones</translation>
    </message>
    <message>
        <location filename="ui_manualStationNaming.ui" line="135"/>
        <source>Auto</source>
        <translation>Auto</translation>
    </message>
</context>
</TS>
